#!/usr/bin/env bash
# Rebuild Arcs_Player_Aid_Alternative.pdf from arcs_player_aid.html
#
# Requires a Chromium/Chrome binary. Set CHROME to override autodetection:
#   CHROME="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" ./build.sh
set -euo pipefail
cd "$(dirname "$0")"

OUT="${1:-Arcs_Player_Aid_Alternative.pdf}"

# The two typefaces are commercial and are not shipped with this source. A browser
# would silently substitute a default font and produce a PDF that looks roughly right
# on screen and wrong in print — so fail loudly instead. See fonts/README.md.
missing=()
for f in fonts/bolyar900.woff2 fonts/kabelbook.woff2; do
  [[ -f "$f" ]] || missing+=("$f")
done
if (( ${#missing[@]} )); then
  echo "Missing required font file(s):" >&2
  printf '  %s\n' "${missing[@]}" >&2
  echo >&2
  echo "These are licensed commercial fonts and aren't distributed with this source." >&2
  echo "See fonts/README.md for what they are and where to get them." >&2
  exit 1
fi

if [[ -z "${CHROME:-}" ]]; then
  for c in \
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
    "/Applications/Chromium.app/Contents/MacOS/Chromium" \
    "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser" \
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge" \
    "$(command -v chromium || true)" \
    "$(command -v google-chrome || true)"
  do
    [[ -n "$c" && -x "$c" ]] && CHROME="$c" && break
  done
fi

if [[ -z "${CHROME:-}" ]]; then
  echo "No Chromium/Chrome found. Set CHROME=/path/to/browser and re-run." >&2
  exit 1
fi

echo "Using: $CHROME"

render() {
  "$CHROME" --headless --disable-gpu --no-pdf-header-footer "$@" \
    --print-to-pdf="$OUT" "file://$PWD/arcs_player_aid.html"
}

# Normal path. If the browser refuses because it's running as root (CI/containers
# only — not a normal desktop), retry once with the sandbox disabled.
if ! render ${CHROME_FLAGS:-} 2>/tmp/arcs_build_err; then
  if grep -q "without --no-sandbox" /tmp/arcs_build_err; then
    echo "Running as root; retrying with --no-sandbox."
    render ${CHROME_FLAGS:-} --no-sandbox
  else
    cat /tmp/arcs_build_err >&2
    exit 1
  fi
fi
rm -f /tmp/arcs_build_err

[[ -s "$OUT" ]] || { echo "Build produced no output." >&2; exit 1; }

echo "Wrote $OUT"
echo
echo "Verify: the PDF must be exactly 2 pages, and must embed ONLY"
echo "FMBolyarRoughNPro-900 and NeueKabelW01-Book. A third font means a"
echo "character fell back — see README.md 'Missing glyphs'."
