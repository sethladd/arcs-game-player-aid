# Fonts go here

Two files are required to build the player aid. They are **not included** — both are commercial
typefaces that can't be redistributed, so you need to supply your own licensed copies.

Drop them in this folder with exactly these names:

| Filename | Typeface | Used for |
| --- | --- | --- |
| `bolyar900.woff2` | FM Bolyar Rough NPro 900 | titles, headers, subheads |
| `kabelbook.woff2` | Neue Kabel — Book weight | all body text |

## Where these fonts come from

Leder Games names them as the game's typefaces in the
[Arcs Official Development Kit](https://ledergames.com/blogs/news/arcs-the-official-development-kit).
The kit does not include the font files themselves — you license them from the foundries:

- **FM Bolyar Rough NPro** — Fontfabric · <https://www.fontfabric.com/fonts/bolyar-sans/>
- **Neue Kabel** — Monotype/Linotype · <https://www.myfonts.com/collections/neue-kabel-font-linotype>

## Already have them in another format?

Any of `.otf`, `.ttf`, `.woff`, or `.woff2` will work — the `@font-face` rules just need the paths to
match. If you have `.otf`/`.ttf`, either point the CSS at them directly (edit the two `@font-face`
`src:` lines at the top of `arcs_player_aid.html`) or convert:

```bash
pip install fonttools brotli
python -c "
from fontTools.ttLib import TTFont
f = TTFont('FMBolyarRoughNPro-900.otf'); f.flavor='woff2'; f.save('fonts/bolyar900.woff2')
f = TTFont('Neue Kabel W01 Book.otf');   f.flavor='woff2'; f.save('fonts/kabelbook.woff2')
"
```

Many licensed font purchases ship a "Web Fonts" folder that already contains a `.woff2` — if so, just
rename it to the filename in the table above.

## Building without them

`build.sh` refuses to run if either file is missing, on purpose. A browser will silently substitute a
default font rather than error, which produces a PDF that looks approximately right on screen and
wrong in print — so the guard fails loudly instead.
